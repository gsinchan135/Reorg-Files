this is DB_error_handling.php
