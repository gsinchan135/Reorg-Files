this is DB_chat.php
