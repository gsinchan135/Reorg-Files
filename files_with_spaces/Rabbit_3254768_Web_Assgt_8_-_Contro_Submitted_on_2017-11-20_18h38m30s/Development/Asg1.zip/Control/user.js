this is user.js
