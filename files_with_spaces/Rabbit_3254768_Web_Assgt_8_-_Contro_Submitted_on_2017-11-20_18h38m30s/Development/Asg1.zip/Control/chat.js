this is chat.js
